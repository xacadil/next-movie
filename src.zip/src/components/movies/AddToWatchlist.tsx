"use client";

import { useEffect, useState } from "react";
import { Bookmark, BookmarkX } from "lucide-react";
import { useAuth } from "@/lib/hooks/useAuth";
import { useMovieStore } from "@/lib/store";
import { doc, getDoc, setDoc, deleteDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useRouter } from "next/navigation";

interface Props {
    movie: {
        id: number;
        title: string;
    };
}

export default function AddToWatchlist({ movie }: Props) {
    const { user } = useAuth();
    const router = useRouter();

    const {
        watchlist,
        addToWatchlist,
        removeFromWatchlist,
    } = useMovieStore();

    const [loading, setLoading] = useState(false);

    const isInWatchlist = watchlist.some((m) => m.id === movie.id);

    const handleToggle = async () => {
        if (!user) {
            router.push("/login");
            return;
        }

        setLoading(true);
        const docRef = doc(db, "users", user.uid, "watchlist", movie.id.toString());

        try {
            if (isInWatchlist) {
                await deleteDoc(docRef);
                removeFromWatchlist(movie.id);
            } else {
                await setDoc(docRef, {
                    id: movie.id,
                    title: movie.title,
                    addedAt: Date.now(),
                });
                addToWatchlist(movie);
            }
        } catch (err) {
            console.error("Failed to update watchlist", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!user || isInWatchlist) return;

        let ignore = false;

        const checkInitialStatus = async () => {
            const docRef = doc(db, "users", user.uid, "watchlist", movie.id.toString());
            const docSnap = await getDoc(docRef);
            if (docSnap.exists() && !ignore) {
                addToWatchlist(movie);
            }
        };

        // checkInitialStatus();
        console.log(watchlist);

        return () => {
            ignore = true; // prevent race condition on unmount
        };
    }, [user, movie.id, isInWatchlist, addToWatchlist, movie]);

    return (
        <button
            onClick={handleToggle}
            disabled={loading}
            className={`inline-flex items-center px-4 py-2 text-sm font-medium text-white rounded-lg ${isInWatchlist ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"
                } transition-colors`}
        >
            {isInWatchlist ? (
                <>
                    <BookmarkX className="w-5 h-5 mr-2" />
                    Remove from Watchlist
                </>
            ) : (
                <>
                    <Bookmark className="w-5 h-5 mr-2" />
                    Add to my Watchlist
                </>
            )}
        </button>
    );
}
