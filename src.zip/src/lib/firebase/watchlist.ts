import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";
import { WatchlistItem } from "@/types/movie";

export async function fetchUserWatchlist(uid: string) {
    const snapshot = await getDocs(collection(db, "users", uid, "watchlist"));
    console.log("snapshot", snapshot.docs);
    return snapshot.docs.map((doc) => doc.data() as WatchlistItem);
}
